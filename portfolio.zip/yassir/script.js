// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Mobile Menu Toggle
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav_links');
  
  if (menuToggle) {
    menuToggle.addEventListener('click', function() {
      menuToggle.classList.toggle('active');
      navLinks.classList.toggle('active');
    });
  }
  
  // Close mobile menu when clicking a nav link
  const navItems = document.querySelectorAll('.nav_links li a');
  
  navItems.forEach(item => {
    item.addEventListener('click', function() {
      navLinks.classList.remove('active');
      menuToggle.classList.remove('active');
    });
  });
  
  // Close mobile menu when clicking outside
  document.addEventListener('click', function(event) {
    const isClickInsideNav = navLinks.contains(event.target);
    const isClickOnToggle = menuToggle.contains(event.target);
    
    if (navLinks.classList.contains('active') && !isClickInsideNav && !isClickOnToggle) {
      navLinks.classList.remove('active');
      menuToggle.classList.remove('active');
    }
  });
  
  // Sticky Header
  const header = document.querySelector('header');
  
  window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
      header.classList.add('sticky');
    } else {
      header.classList.remove('sticky');
    }
  });
  
  // Scroll to Top Button
  const scrollUp = document.getElementById('scrool-up');
  
  window.addEventListener('scroll', function() {
    if (window.scrollY > 300) {
      scrollUp.classList.add('srcl');
    } else {
      scrollUp.classList.remove('srcl');
    }
  });

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        // Offset for header height
        const headerHeight = document.querySelector('header').offsetHeight;
        const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
        
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Add animation to skill items on scroll
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate');
      }
    });
  }, { threshold: 0.1 });
  
  document.querySelectorAll('.items > div').forEach(item => {
    observer.observe(item);
  });
  
  // Set initial animation delay for skills to create staggered effect
  document.querySelectorAll('.items > div').forEach((item, index) => {
    item.style.transitionDelay = `${index * 0.1}s`;
  });

  // Initialize animations on load
  setTimeout(() => {
    document.querySelectorAll('.items > div').forEach(item => {
      if (isElementInViewport(item)) {
        item.classList.add('animate');
      }
    });
  }, 300);

  // Helper function to check if element is in viewport
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  }
});